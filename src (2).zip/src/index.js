import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
//import App from'./App'

import Pages from './Router'
import Characters from './Characters'
import ComicList from './comics'
// import * as firebase from 'firebase';

//  var config = {
//     apiKey: "AIzaSyDW0Ay060zEm_G_tzB1lz5K2Imtt3qDVg4",
//     authDomain: "react-202909.firebaseapp.com",
//     databaseURL: "https://react-202909.firebaseio.com",
//     projectId: "react-202909",
//     storageBucket: "",
//     messagingSenderId: "1064609949465"
//   };
//   firebase.initializeApp(config);







//import App from './App';
//import registerServiceWorker from './registerServiceWorker';

// ReactDOM.render(
//   <Pages />,
//   document.getElementById('pages')
// 	);



ReactDOM.render(
  <Characters />,
  document.getElementById('root')
);

