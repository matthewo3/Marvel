// import React from 'react';
// import md5 from 'md5';





// class ComicList extends React.Component {

//   constructor(){
//     super();
//     this.state = {
//       characters: [],
//       character: ''
//     };

//     this.handleChange = this.handleChange.bind(this);
//     this.handleSubmit = this.handleSubmit.bind(this);
//   }
//   handleChange(event) {
//     this.setState({character: event.target.value});
// }

// handleSubmit(event) {
//   this.setState({character: event.target.value});
   
//        //Create MD5 hash
//     let API_KEY = '6dd5718bb1b01f2f8788a84c8cb850ab';
//     let PRIV_KEY = '938a0a2150e82de9fb1b69bab4dc3ee593963537';
//     let ts = new Date().getTime();
//     let hash = md5(ts + PRIV_KEY + API_KEY);
//     console.log('hash: ' +hash);
//      console.log('ts: ' + ts);

//    let url = `https://gateway.marvel.com:443/v1/public/characters?name=${this.state.character}&apikey=${API_KEY}&hash=${hash}&ts=${ts}`;
//     fetch(url)
//      .then(response => {
//       if(response.ok) return response.json();
//       throw new Error('Request failed.');
//     })
//     .then(data => {
//       console.log('test');
//       this.setState({characters: data.data.results});
//       console.log(data.data.results);
//     })
//     .catch(error => {
//       console.log(error);
//     });
//     if(this.state.character!==''){
//       event.preventDefault();
//   }
//   }


//     render() {
//     let list; 
//     list = this.state.characters.map( (u, i) => {
//         return <Comic name={u.title}/>;

//     });
//     return (
//       <div className="main">
//       <div className="hero-search">

//       <form onSubmit={this.handleSubmit}>
//        <h1>Search Your Favourite Marvel Comic</h1>
//           <input type="text"  value={this.state.value} onChange={this.handleChange}/>
//           <input type="submit"  value="Submit"/>
//         </form> 
//         </div>
    
//         {list}
//       </div>
//     );
//   }
// }
  


// class Comic extends React.Component {
//   render() {
//     return (
//       <div>
//         <div className="hero-name">
//         <h1>{this.props.name}</h1>
//         </div>
//       </div>
//     );
//   }
// }

// export default ComicList;