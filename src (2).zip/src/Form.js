import React from 'react';

const Form = props =>(
	
	<form onSubmit={props.componentWillMount}>
		<input type="text" name="heroName" placeholder="Characters Name..."/>
		<button>Search Hero</button>
	</form>
);

export default Form;