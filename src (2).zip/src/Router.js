import React from 'react'
import {BrowserRouter, Route, Link} from 'react-router-dom';

class Pages extends React.Component {
  render() {
    return(

      <BrowserRouter>
        <div className="container">
        <div className="nav">
        
            <h1><Link to="/Clicky">Clicky</Link></h1>
          

          <hr/>

          {/* The exact keyword ensures the '/' route matches only '/' and not '/anything-else'--> */}
          <Route path="/Clicky"/>
        </div>
        </div>
      </BrowserRouter>
    );
  }
}

export default Pages;