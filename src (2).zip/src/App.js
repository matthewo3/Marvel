import React, { Component } from 'react';
import './App.css';

class App extends Component {
  render() {
    return (
      <div>
          <NameLength name="johnny" />
          <NameLength name="Gillian" />
          <NameLength name="Jordan" />
      </div>
    );
  }
}

function NameLength(props){
  return <h1>The Name {props.name} 
  contains {props.name.length} characters!</h1>;
}

export default App;
